# Lungs Data > 2024-08-11 2:20am
https://universe.roboflow.com/sparmar/lungs-data

Provided by a Roboflow user
License: CC BY 4.0

